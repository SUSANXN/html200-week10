var person = new Object();

person["firstName"] = "Jason";
person["lastName"] = "zeringue";

